namespace FloatJudge.Tests
{
    public class FloatTests
    {
        [Theory]
        [InlineData(false, "")]
        [InlineData(false, " ")]
        [InlineData(false, "+")]
        [InlineData(false, "-")]
        [InlineData(false, ".")]
        [InlineData(false, "+.")]
        [InlineData(false, "-.")]
        [InlineData(false, "+0+")]
        [InlineData(false, "-0-")]
        [InlineData(true, "+1")]
        [InlineData(true, "-1")]
        [InlineData(true, "1")]
        [InlineData(true, "+1.")]
        [InlineData(true, "-1.")]
        [InlineData(true, "1.")]
        [InlineData(true, "+.1")]
        [InlineData(true, "-.1")]
        [InlineData(true, ".1")]
        [InlineData(true, "+1.1")]
        [InlineData(true, "-1.1")]
        [InlineData(true, "1.1")]
        [InlineData(false, "1e")]
        [InlineData(false, "1E")]
        [InlineData(false, "1e+")]
        [InlineData(false, "1E+")]
        [InlineData(false, "1e-")]
        [InlineData(false, "1E-")]
        [InlineData(true, "1e+1")]
        [InlineData(true, "1E+1")]
        [InlineData(true, "1e-1")]
        [InlineData(true, "1E-1")]
        [InlineData(true, "1e1")]
        [InlineData(true, "1E1")]
        [InlineData(true, "1.e1")]
        [InlineData(true, "1.E1")]
        [InlineData(true, ".1e1")]
        [InlineData(true, ".1E1")]
        [InlineData(false, "1e1.")]
        [InlineData(false, "1E1.")]
        [InlineData(true, "+1234567890.0123456789e+1234567890")]
        [InlineData(true, "+.0123456789e+1234567890")]
        [InlineData(true, "+1234567890.e+1234567890")]
        public void FloatTest(bool expected, string s)
        {
            Assert.Equal(expected, FloatJudge.IsFloat(s));
        }
    }
}