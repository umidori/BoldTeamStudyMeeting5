﻿using System.Security.Cryptography;

namespace FloatJudge
{
    public class FloatJudge
    {
        static public bool IsFloat(string s)
        {
            var len = s.Length;
            var i = 0;

            goto S0;

        S0: if (i >= len)
            {
                goto S9;
            }
            else if (s[i] == '+' || s[i] == '-')
            {
                i++;
                goto S1;
            }
            else if (s[i] == '.')
            {
                i++;
                goto S2;
            }
            else if ('0' <= s[i] && s[i] <= '9')
            {
                i++;
                goto S3;
            }
            else
            {
                goto S9;
            }
        S1:
        S2:
        S3:
        S4:
        S5:
        S6:
        S7:
        S8: return true;
        S9: return false;
        }
    }
}