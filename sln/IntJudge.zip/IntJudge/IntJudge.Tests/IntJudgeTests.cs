namespace IntJudge.Tests
{
    public class IntTests
    {
        [Theory]
        [InlineData(false, "")]
        [InlineData(false, " ")]
        [InlineData(false, "+")]
        [InlineData(false, "-")]
        [InlineData(false, "++")]
        [InlineData(false, "--")]
        [InlineData(false, "+0+")]
        [InlineData(false, "-0-")]
        [InlineData(true, "+0123456789")]
        [InlineData(true, "-0123456789")]
        [InlineData(true, "0123456789")]
        public void IntTest(bool expected, string s)
        {
            Assert.Equal(expected, IntJudge.IsInt(s));
        }
    }
}