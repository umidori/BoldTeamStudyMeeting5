﻿namespace IntJudge
{
    public class IntJudge
    {
        static public bool IsInt(string s)
        {
            var len = s.Length;
            var i = 0;

            goto S0;

        S0: if (i >= len)
            {
                goto S4;
            }
            else if (s[i] == '+' || s[i] == '-')
            {
                i++;
                goto S1;
            }
            else if ('0' <= s[i] && s[i] <= '9')
            {
                i++;
                goto S2;
            }
            else
            {
                goto S4;
            }
        S1:
        S2:
        S3: return true;
        S4: return false;
        }
    }
}